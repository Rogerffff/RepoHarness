# 02_SWE17_16_15：来源补充附件

采集于 2026-09-11。请先读对应原文，再用这些附件补充图表、公式和交互示例。它们不构成精读结论，也不代表训练复现。阅读应覆盖完整正文、附录和图表，不要只围绕资料补缺项作答。

## 阅读入口

### SWE-1.7: Frontier Intelligence at a Fraction of the Cost | Cognition

原始网页：https://cognition.com/blog/swe-1-7

- [swe-1-7/reading_text.md](swe-1-7/reading_text.md)：网页提取正文。
- [swe-1-7/visual_supplement.pdf](swe-1-7/visual_supplement.pdf)：图表截图 PDF；逐页文件映射见 [swe-1-7/VISUAL_INDEX.md](swe-1-7/VISUAL_INDEX.md)。
- `swe-1-7/states/`：交互状态截图与文本。
- `swe-1-7/embedded/`：官网脚本中的完整示例；先看 manifest.json。
- `public_data/data/swe-1-7/`：官网公开 JSON 原文件。

### An Early Preview of SWE-1.6 and Research Update | Cognition

原始网页：https://cognition.com/blog/swe-1-6-preview

- [swe-1-6-preview/reading_text.md](swe-1-6-preview/reading_text.md)：网页提取正文。
- [swe-1-6-preview/visual_supplement.pdf](swe-1-6-preview/visual_supplement.pdf)：图表截图 PDF；逐页文件映射见 [swe-1-6-preview/VISUAL_INDEX.md](swe-1-6-preview/VISUAL_INDEX.md)。

### Introducing SWE-1.5: Our Fast Agent Model | Cognition

原始网页：https://cognition.com/blog/swe-1-5

- [swe-1-5/reading_text.md](swe-1-5/reading_text.md)：网页提取正文。
- [swe-1-5/visual_supplement.pdf](swe-1-5/visual_supplement.pdf)：图表截图 PDF；逐页文件映射见 [swe-1-5/VISUAL_INDEX.md](swe-1-5/VISUAL_INDEX.md)。


1.7 的 embedded/array-139353.json 包含 3 个 CoT 示例；array-151019.json 包含 3 个轨迹示例。网页内部字段 swe2 对应页面的 SWE-1.7 栏，不能仅凭字段名认定为 SWE-2。

## 使用边界

截图 PDF 是本次制作的视觉附件，不是作者发布的 PDF。网页公开的展示轨迹不等于完整训练日志。来源没有披露的训练配方和数值，不得由示意图或脚本变量名推断成事实。
本地完整 HTML/MHTML 底稿单独保留；本 ZIP 优先携带 Pro 可直接阅读的 Markdown、JSON、PDF 与图像。
