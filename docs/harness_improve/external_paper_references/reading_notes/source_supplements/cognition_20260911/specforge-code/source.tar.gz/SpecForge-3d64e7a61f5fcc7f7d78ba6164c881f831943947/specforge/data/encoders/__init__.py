"""Model-specific prompt encoders."""
