"""Algorithm contract tests."""
